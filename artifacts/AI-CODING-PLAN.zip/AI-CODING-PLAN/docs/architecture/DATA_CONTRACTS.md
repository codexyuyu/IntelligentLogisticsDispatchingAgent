# 共享数据与接口契约 · 1.0.0

这是架构冻结输入；类型实施任务见TASK_MANIFEST。所有跨模块输入输出均具名且有版本，禁止任意dict/Any穿越边界。列表字段为tuple或显式list[T]，可选字段用T|None且有缺失语义；Pydantic边界`extra=forbid`，纯domain不依赖Pydantic。字段实现后由Python导出JSON Schema和OpenAPI，本文随破坏变更修订，禁止产生另一个手写标准。

## 公共类型与状态

`EntityRef(kind: EntityKind, id: UUID, revision: int?)`；`ArtifactRef(id: UUID, media_type: str, sha256: str, relative_path: SafeArtifactPath)`；`ResourceRevision(entity_ref, row_version)`；`TimeWindow(earliest_s:int, latest_s:int)`；`Load(weight_g:int, volume_cm3:int)`；`ResourceRequirement(resource_kind, eligible_ids:tuple[UUID], units:int)`；`CalendarInterval(start_s,end_s,available_units:int)`；`ResourceCalendar(intervals:tuple[CalendarInterval], version:int)`；`ConstraintParameters` 按ConstraintCode判别，不接受自由key-value。

`SolveStatus = OPTIMAL | FEASIBLE | INFEASIBLE | TIMEOUT | UNKNOWN | INVALID_INPUT | ERROR | CANCELLED`。TIMEOUT可以有经验证incumbent，具体以candidate与validation判断；无incumbent不能报告可行。`feasibility = VALID | INVALID | UNKNOWN`。`JobStatus = queued | running | completed | failed | cancelled`：completed表示工作已执行并产出typed结果，优化可能INFEASIBLE/TIMEOUT；worker自身崩溃/代码错误重试耗尽才failed。`MetricSource = planned | simulation | actual`。`ActorRole = viewer | operator`。

`ErrorEnvelope(schema_version, code:ErrorCode, message:str, trace_id:UUID, retryable:bool, details:tuple[ErrorDetail])`。`ErrorDetail`为FieldError(field_path,rule,expected:str,actual:str)、ConflictDetail(entity_ref,expected_revision,actual_revision)、UnsupportedDetail(capability)判别联合；不要输出完整原输入或密钥。

错误表：INVALID_INPUT/INVALID_TRANSITION/DEPENDENCY_CYCLE→422；UNAUTHENTICATED→401；FORBIDDEN/TOOL_FORBIDDEN→403；NOT_FOUND→404；STALE_SNAPSHOT/RESOURCE_CONFLICT/IDEMPOTENCY_CONFLICT/CONFIRMATION_EXPIRED→409；REQUEST_TOO_LARGE→413；RATE_LIMITED→429；PROVIDER_UNAVAILABLE/DEPENDENCY_UNAVAILABLE→503；INTERNAL_ERROR→500。求解无解/超时是已完成作业的result状态，不伪装HTTP500。MANUAL_REQUIRED、NO_FEASIBLE_CANDIDATE是业务结果原因；未实现能力在开发期间HTTP501，禁止进入对应Gate。

## 关键 Schema（未列的实体字段继承 DOMAIN_CATALOG）

| Schema | 必需字段与边界语义 | 实施归属 |
| --- | --- | --- |
| PlanningScope | order_ids:tuple[UUID]; warehouse_ids:tuple[UUID]; vehicle_ids:tuple[UUID]; epoch_utc:datetime; horizon_s:int | P02-03 |
| PlanningSnapshot | id; scope; orders:tuple[Order]; cargo:tuple[Cargo]; vehicles:tuple[Vehicle]; drivers:tuple[Driver]; resources:ResourceBundle; inventory:tuple[InventoryEntry]; revisions:tuple[ResourceRevision]; matrices:tuple[TravelMatrix]; hash:str | P02-03/P03-03 |
| SolveBudget | wall_time_ms:int(1..60000); deadline_utc:datetime; max_candidates:int(1..10); seed:int; worker_count:int(默认1); deterministic_test_mode:bool | P02-03 |
| ObjectivePolicy | version:str; optional_unserved_penalty_cents:int; soft_late_cents_per_s:int; makespan_cents_per_s:int; disturbance_weights:DisturbanceWeights；均非负且int64上界检查 | P02-03 |
| EngineMetadata | name; version; configuration_hash; seed; workers; input_hash; solve_ms; build_ms; engine_status; incumbent_exists; best_bound:int?; optimality_gap:float? | P02-03 |
| ValidationReport | id; candidate_hash; snapshot_hash; rules_version; valid:bool; required_codes:tuple[ConstraintCode]; checked_codes:tuple[ConstraintCode]; unsupported_codes; violations:tuple[Violation]; validated_at | 纯类型P02-03；边界/注册P10-01 |
| Violation | code; severity; entity_refs; field_path; actual:str; expected:str; message:str | P02-03 |
| CandidatePlan | id; schedule_id; base_version_id?; snapshot_id; snapshot_hash; epoch_utc; horizon_s; transport_plan:TransportPlan; warehouse_plan:WarehousePlan; task_assignments:tuple[ScheduleTask]; objective; content_hash; solver_evidence_refs:tuple[UUID] | P02-03 |
| SolverEvidence | id; engine_name:routing/cp_sat; engine_version; input_hash; assignment_hash; configuration_hash; solve_status; trusted_job_id:UUID?；纯内核结果此字段可空，可信worker存储时绑定实际job，正式提交必须非空；Agent自报无效 | P02-03；P07/P09/P16填充 |
| CostBreakdown | distance_cents; fixed_vehicle_cents; service_cents; overtime_cents; setup_cents; total_cents；total仅这五项实际成本之和，不含任何优化罚分 | P02-03 |
| ObjectiveBreakdown | business_cost_cents; optional_unserved_penalty; soft_late_penalty; disturbance_penalty; makespan_penalty; objective_total；业务成本与罚分各计一次，不将objective_total称运输总成本 | P02-03 |
| TransportRequestDTO | schema_version; scope; order_ids; vehicle_ids; matrix_ref; constraints:tuple[ConstraintDTO]; budget; objective_policy | P06-01 |
| TransportProblem | snapshot; nodes:tuple[RoutingNode]; vehicles:tuple[VehicleState]; pickup_delivery_pairs; matrix; constraints; policy | P06-01 |
| RoutingNode | id; kind:depot/pickup/delivery/virtual_start; order_id?; location_id; service_s; hard_window; soft_due_at_s?; load_delta:SignedLoad | P06-01 |
| VehicleState | vehicle_id; driver_id; start_node_id; end_node_id; start_load; capacity; setpoint_decic; available_window; max_drive_s; allowed_cargo_types | P06-01 |
| TransportSolution | status; engine_metadata; candidate:TransportPlan?; optional_unserved_order_ids; objective?; validation:ValidationReport?; diagnostics:tuple[Diagnostic]; solver_evidence:tuple[SolverEvidence] | P06-01 |
| MatrixQuery / TravelMatrix | query含ordered_node_ids/profile/time_bucket/expected_version；matrix含id/version/node_ids/distance_m:tuple[tuple[int or null]]/travel_s同形/source/observed_at/hash；None为不可达，成对一致 | 纯矩阵值P02-03；Query/DTO/Provider P06-02 |
| WarehouseRequestDTO / WarehouseProblem | scope; snapshot; tasks:tuple[WarehouseTask]; calendars; initial_inventory; storage_intervals; setup_policy; handoffs; objective; budget | P08-01/02 |
| WarehouseSolution | status; assignments:tuple[OperationAssignment]?; storage_allocations; setup_operations; objective?; validation?; engine_metadata; diagnostics; solver_evidence:tuple[SolverEvidence] | P08-01 |
| HandoffConstraint | order_id; predecessor_task_id; successor_task_id; location_id; min_transfer_s; cargo_units; kind:load_before_depart/unload_after_arrive/storage_conservation | P08-02 |
| SetupPolicy | version; transitions:tuple[SetupTransition(resource_kind,from_class,to_class,duration_s,requirements,cost_cents)] | P08-01 |
| SimulationRequest | schema_version; scenario_ref; schedule_version_id; validated_plan; seed; until_s; stochastic_policy:StochasticPolicy; source=simulation | P11-01 |
| TwinState | time_s; orders:tuple[OrderExecution]; vehicles:tuple[VehicleExecution]; warehouses:tuple[WarehouseExecution]; inventory; resource_usage; last_event_seq | 纯值P02-04；仿真映射P11-01 |
| PendingEvent / RngState | event_id,time_s,priority,insertion_seq,payload:ExecutionEventPayload；rng含stream_name、algorithm_version、typed integer state、draw_count | 纯值P02-04；仿真映射P11-01 |
| SimulationSnapshot | 见实体目录，完整TwinState+pending_events+rng_states+source_plan_hash+schema_version | P11-01 |
| SimulationResult / SimulationView | simulation_id; status; time_s; snapshot_ref; event_cursor; execution_summary; seed; source；Result另含final_state_hash、artifacts | P11-01/P16-04 |
| SimulationControl | action:pause/resume/step; control_seq:int; expected_revision:int; advance_to_s:int? | P16-04 |
| EventEnvelope | schema_version; source; source_event_id; kind; occurred_at_utc; simulation_id?; payload:EventPayload; expected_revision? | P13-01 |
| ImpactReport | event_ids; base_version_id; execution_snapshot_id; affected_tasks; affected_orders; affected_resources; reason_paths:tuple[ImpactPath]; boundary_refs | P14-01 |
| RescheduleBoundary | event_time_s; frozen_tasks; interrupted_tasks; virtual_starts; residual_loads; resource_blocks; mutable_task_ids; immutable_hash | P14-02 |
| AdjustmentSpec | id; strategy:reassign/defer/alternate_resource/rescue/return; changed_constraint_refs; rescue_tasks; assumptions:tuple[VerifiedAssumption] | P15-01 |
| RescheduleProblem / RescheduleRequestDTO | base_version; execution_snapshot; events; impact; boundary; candidate_policies; budget; objective_policy | P14-01/P15-02 |
| RescheduleSolution | status; rounds:tuple[SearchRound]; candidates:tuple[CandidateEvaluation]; selected_candidate_id?; comparison:ScheduleDiff?; manual_requirements | P15-02 |
| ScheduleDiff | base_version_id; candidate_id; changed_tasks:tuple[TaskChange]; added_cost:int; delay_difference:int; resource_changes:tuple[ResourceChange]; affected_orders:tuple[UUID]; constraint_results:ValidationComparison; disturbance:DisturbanceScore | P15-04 |
| JointPlanningRequest / JointPlanningResult | scope,budget,policy；结果含status/rounds/offers/candidate/validation/engine_metadata，预算贯穿所有子问题 | P16-02 |
| WarehouseWindowOffer | id; snapshot_hash; warehouse_id; order_ids; ready_at_s; receiving_windows; resource_summary; expires_at；不含正式预留 | P16-02 |
| CommitCommand | schedule_id; candidate_id; candidate_hash; expected_active_version_id?; snapshot_hash; idempotency_key; confirmation_token? | P02-03/P16-03 |
| CommitReceipt | schedule_id; version_id; version_no; parent_version_id?; content_hash; audit_id; trace_id; committed_at | P02-03 |
| JobRequest / JobRef | kind判别payload(Optimization/Simulation/Reschedule/Experiment/Metric)；Ref含job_id,status,status_url,result_url,trace_id | P05-03，后续仅按冻结union补实现 |
| ToolSpec / ToolCallRequest | name、description、args_schema、required_role、effect:read/propose/commit；call含run_id、call_id、name、arguments:ToolArguments、deadline、idempotency_key、expected_revision | P17-01 |
| ToolResult | call_id; status:success/error/pending; data:ToolData判别联合; error:ErrorEnvelope?; trace_id; audit_ref | P17-01 |
| LLMRequest / LLMResponse | typed Messages/ToolSpecs/response_schema/budget；响应TextPart/ToolProposal联合+usage+provider_request_id；没有ScheduleVersion写入字段 | P18-01 |
| IntentDraft | intent; entity_refs; constraints:tuple[ConstraintProposal]; missing_fields; questions; evidence:tuple[SourceSpan]; ready:bool | P19-01 |
| AgentRequest / AgentOutcome | actor/run/conversation/message/deadline/budget；Outcome status、candidate_refs、questions、explanation、decision_ref；不承载自由生成路线 | P19-02 |
| EvidenceExplanation | summary; facts:tuple[FactRef]; statements:tuple[EvidenceStatement(text,fact_ids,kind:fact/prediction/recommendation)]; generator:model/template | P20-02 |
| ConfirmationToken | opaque随机token对外，仅hash入库；绑定actor/run/candidate_hash/expected_revision/expires_at；有效期默认300秒，一次消费可幂等重放原receipt | P23-02 |
| RealtimeEnvelope | schema_version; seq:int; event_id; topic:Topic; entity_ref; revision; payload:RealtimePayload联合；不推敏感全量实体 | P31-01 |
| EvaluationInput / MetricSet | scope_id/source/window/eligible_orders/execution_facts/availability/costs/latency_samples；MetricSet含definition_version、values、sample_count、coverage、missing_reasons | P32-01 |
| ExperimentSpec | scenario_ref; policy_ids; paired_seeds; repetitions>=10; equal_budget; metric_version; stop_policy; environment_fingerprint | 纯值P02-04；实验行为P33-01 |

所有`Protocol`使用本表的纯domain类型或明确view模型；HTTP/Tool边界使用对应DTO，应用层负责映射。`ServiceBundle`是具名服务字段的组合结构，不能`dict[str,object]`服务定位器。`ToolArguments`按ToolName判别到对应服务请求DTO。未列小型UI Props必须从生成客户端类型组合，不能新定义业务实体。

## EventPayload 十类精确定义

公共 `entity_ref`、`effective_at_s`、`reason` 均必填。vehicle_failure(vehicle_id,location:ExecutionLocation,unavailable_until_s?,cargo_condition:CargoCondition)；transport_delay(transport_task_id,additional_seconds>0)；traffic_disruption(arc_refs,closure:bool,travel_multiplier:Rational?,new_matrix_version)；weather_change(region_ref,profile:WeatherProfile,travel_multiplier:Rational,new_matrix_version)；cargo_anomaly(cargo_id,condition:temperature_excursion/damaged/missing,quantity_units,measured_temp_decic?)；order_cancellation(order_id,disposition_policy:ReturnPolicy)；demand_increase(order_id,delta_quantity>0,delta_weight_g>0,delta_volume_cm3>0)；demand_decrease(order_id,delta_quantity>0,delta_weight_g>0,delta_volume_cm3>0)；equipment_failure(equipment_id,unavailable_until_s?,remaining_capacity_units>=0)；warehouse_resource_unavailable(resource_ref,unavailable_window,remaining_capacity_units>=0)。

增/减是独立kind，delta均正；应用时总量不得负，已执行数量不能减少。天气/交通产生新矩阵，保留来源和有理倍率；未发生的路段受新数据影响，在途路段以实际位置和剩余段单独重建，不能改写历史。迟到事件标记quarantined/reprojection_required，待重投影生成新快照后再分析。

## 冻结的服务 / Protocol 方法

阶段间类型依赖规则：P02-03的`domain/planning.py`完整定义Route/RouteStop、TransportPlan、WarehousePlan、CandidatePlan、SolveBudget和ValidationReport等纯值类型，不能等P06/P08/P10才出现被P03引用的类型。P02-04的`domain/execution.py`定义TwinState、ExecutionEvent、PendingEvent、RngState；`domain/runtime.py`定义AgentBudget、ExperimentSpec等运行实体所需纯值类型。P11/P17/P33等后续阶段只新增该能力的请求映射、Problem组装、Protocol与实现，引用早期实体和纯值类型，不再创建同名第二份定义。运行实体DTO在`contracts/runtime.py`，仿真请求/响应DTO在`contracts/simulation.py`，职责不同。Schema所需类型必须真正可实例化，不能用Any、空类或TODO代替。

`ScenarioSpec`的纯数据形状也在P02-04定义，P04负责生成；`ScenarioEngine`的加载实现可在P12-04装配。P02的Schema导出仅依赖完整contracts类型；P05才将已实现路由OpenAPI加入同一导出器，不能让P02导入尚不存在的FastAPI应用。

| 接口 | 签名 | 允许副作用 |
| --- | --- | --- |
| TransportSolver | solve(problem:TransportProblem,budget:SolveBudget)->TransportSolution | 无，受限CPU计算 |
| WarehouseScheduler | solve(problem:WarehouseProblem,budget:SolveBudget)->WarehouseSolution | 无 |
| JointPlanningSolver | solve(problem:JointProblem,budget:SolveBudget)->JointCandidateSolution | 无；有限轮次仓运窗口反馈，P15首次实现、P16服务复用 |
| ConstraintValidator | validate(plan:CandidatePlan,snapshot:PlanningSnapshot)->ValidationReport | 无；独立重算 |
| RescheduleSolver | solve(problem:RescheduleProblem,budget:SolveBudget)->RescheduleSolution | 无 |
| TravelMatrixProvider | get_matrix(query:MatrixQuery)->TravelMatrix | adapter可读缓存/已批准数据源；solver回调禁止调用 |
| DigitalTwinEngine | apply(state:TwinState,event:ExecutionEvent)->TwinState | 纯投影 |
| SimulationEngine | run(request:SimulationRequest)->SimulationResult | 仅仿真分支内 |
| EventEngine | ingest(envelope:EventEnvelope)->EventReceipt | 由应用服务事务保存，不直接修改计划 |
| ScenarioEngine | load(ref:ScenarioRef)->ScenarioBundle | 只读 |
| PlanningSnapshotStore | capture(scope:PlanningScope)->PlanningSnapshot | 一致性只读事务 |
| PlanCommitStore | commit(cmd:CommitCommand,report:ValidationReport)->CommitReceipt | 由ScheduleService调用，单事务 |
| ScheduleService | commit(cmd:CommitCommand,actor:ActorContext)->CommitReceipt | 唯一正式计划提交用例 |
| ImpactAnalyzer | analyze(event:ExceptionEvent,snapshot:ExecutionSnapshot,plan:ScheduleVersion)->ImpactReport | 无 |
| ToolExecutor | execute(call:ToolCallRequest,context:ToolContext)->ToolResult | 白名单业务服务 |
| LLMProvider | complete(request:LLMRequest)->LLMResponse | 模型网络访问，仅adapter |
| AgentOrchestrator | run(request:AgentRequest)->AgentOutcome | 工具调用与AgentRun记录 |
| MetricCalculator | compute(input:EvaluationInput)->MetricSet | 无 |
| ExperimentRunner | run(spec:ExperimentSpec)->ExperimentResultBundle | 隔离实验分支与结果留档 |

## 兼容变更

设计目标新契约1.0.0；已有demo 0.1.0仅迁移输入，不能悄悄改版本文件覆盖旧基线。破坏字段/单位/enum/路径/必需语义升major，新增可选字段升minor，兼容修复升patch。先写`contracts/changes/`说明，再同一集成修改domain→DTO→ports→调用方→测试→导出物；非阻断架构问题写`docs/architecture/issues/`继续本任务，不顺手重构。方案hash规范排除创建时间、生命周期投影与耗时，只包含稳定业务内容；包含schema/rules/matrix版本，采用UTF-8、排序键、整数和明确null。

规范化方案hash另排除随机生成的candidate/version/route记录ID和solver_evidence记录ID，但包含稳定订单/任务/车辆/资源ID、路线节点顺序与所有业务时刻/载荷/费用。SolverEvidence.assignment_hash绑定该规范化内容，可信job_id可追溯真实引擎执行。正式提交必须解析非空solver_evidence_refs，核验引擎来源与assignment_hash再独立验证；只有一份valid=true的报告不能把LLM或规则手造候选变成正式计划。缺可信证据返回UNVERIFIED_SOLVER_RESULT/422。纯内核输出待存的typed evidence，由应用worker事务持久化并绑定job，内核不查库。
