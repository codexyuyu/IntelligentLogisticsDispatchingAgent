# P07-02 · 实现重量、容积和提送货载荷约束

计划版本1.0.0 · 状态planned · 阶段Gate G07

## Context

你是本项目的Coding Agent。本项目以LLM工具调用 + OR-Tools确定性优化 + SimPy推演 + FastAPI/React/PostgreSQL实现冷链优先调度。当前任务位于Phase 07「Transport Solver」，任务ID `P07-02`，负责方 `B`。只执行本任务，不实现整个模块或后续阶段。

本Prompt连同仓库内契约足以工作，不依赖历史聊天。开始时读取以下本地规范；字段以契约实施后的唯一Python类型为准，文档若冲突先记录issue：

- [总体设计](../../../PROJECT_MASTER_PLAN.md)
- [领域模型](../../../docs/architecture/DOMAIN_CATALOG.md)
- [类型与Protocol](../../../docs/architecture/DATA_CONTRACTS.md)
- [HTTP与Tool](../../../docs/api/API_CONTRACT.md)
- [优化与硬约束](../../../docs/algorithms/OPTIMIZATION_CONTRACT.md)
- [仿真与回放](../../../docs/algorithms/SIMULATION_CONTRACT.md)
- [指标公式](../../../docs/algorithms/METRICS_CONTRACT.md)
- [测试数据](../../../docs/plan/TEST_FIXTURES.md)
- [内部接口与接线](../../../docs/architecture/IMPLEMENTATION_CONVENTIONS.md)
- [Gate](../../../docs/plan/PHASE_GATES.md)

## Current State

理论上以下依赖已经交付且证据有效：`G06、P07-01`。用TASK_GRAPH和Gate证据逐项核验，不能仅根据文件名存在认定完成。

本计划初始所有任务为planned，Gate为not_run；当前旧`demo/`是0.1骨架/展示资产，不代表本任务已实现。目标工作根为含PROJECT_MASTER_PLAN.md的目录，新包在apps/和packages/；旧demo只读，不从教学探针导入。若前置缺失/失败，报告具体阻断并修复前置任务，禁止跳Gate。

## Objective

实现重量、容积和提送货载荷约束。唯一可验收交付物为下述Files对应实现/文档，以及本任务明确测试证据。

## Scope

仅实现 `capacity-and-pickup` 所属能力，遵循下面Business Rules和Algorithm。允许的实现、测试、文档文件完整列于Files。跨模块依赖通过既有Protocol注入。当前任务并行候选：无，按阶段内依赖顺序执行；即使列出候选，运行前仍检查实际写集合与依赖。

## Out of Scope

禁止顺手实现后续阶段、重新设计架构、改另一所有者实现掩盖集成错误、引入微服务/Kubernetes/队列集群/复杂GIS/复杂权限/3D关键依赖。测试替身不得进正式bootstrap。除Files及经明确记录的阻断契约迁移外，其他文件均不在范围。

## Architecture Constraints

1. Domain Contract → Schema → Service Interface → Implementation → Test → Integration，跨边界不传未经定义dict/Any。
2. LLM只抽取/分解/调用/解释，不自由生成最终调度；Agent只经工具到应用服务，不能直写数据库。
3. Solver候选必须经确定性独立硬校验；正式提交只能由ScheduleService完成，重排追加ScheduleVersion不覆盖历史。
4. Domain不导入框架/ORM/模型SDK；application不导入adapters，bootstrap唯一装配点；React不硬编码业务规则或另写枚举。
5. 不擅自改公共接口。发现架构问题先记录`docs/architecture/issues/`；非阻断继续限定任务，阻断只做最小契约迁移并更新所有受影响调用方/测试/导出物，禁止大规模重构。
6. 禁止TODO占位核心逻辑、fake implementation、hard-coded demo answer、绕过Solver、只写代码不写测试、吞掉Exception、重复定义Domain Model。开发时未实现部分必须显式失败，不能返回固定成功。

## Files

预计创建（若前置已创建则仅核对并增量修改）：

- `docs/implementation/P07-02.md`
- `docs/implementation/reports/P07-02.md`
- `packages/optimization/src/logistics_optimization/transport/capacity.py`
- `tests/integration/test_p07_02_capacity_and_pickup.py`
- `tests/solver/test_p07_02_capacity_and_pickup.py`
- `tests/unit/test_p07_02_capacity_and_pickup.py`

预计修改已有前置产物：

- 无；如运行时已存在同名文件，核对前置产物后只做本任务范围增量。

禁止修改：`demo/`、`demos/`教学代码、非本任务文件、已提交历史版本或审计内容。`contracts/*.json`和`generated.ts`若列入范围只能运行生成器更新，不得手改。包marker只有确需导出本任务类型时可修改，须先在完成报告列出精确路径；不能借此越过接口边界。

## Domain Model

Cargo、PickupDeliveryPair、LoadState。实体字段/状态/生命周期以DOMAIN_CATALOG为准；本任务新增的非实体view只组合既有字段。每实体继承UUID、唯一status Enum、UTC created_at/updated_at、row_version、schema_version，不复制业务模型。

## Input

正式输入由Interfaces的签名左侧和DATA_CONTRACTS相应具名Schema定义：

TransportProblem(snapshot,nodes:tuple[RoutingNode],vehicles:tuple[VehicleState],matrix:TravelMatrix,constraints,policy)；TransportSolution(status,engine_metadata,candidate:TransportPlan|None,validation:ValidationReport|None,diagnostics)。RoutingNode含业务ID、pickup/delivery类型、service_s、hard_window、load_delta；VehicleState含起终点、start_load、两维容量、setpoint、司机班次。

必须覆盖Test Cases给出的具体输入变体；使用TEST_FIXTURES的完整T1/W1/I1/S1/M1定义，未指出的字段保持原值。HTTP边界额外携带actor、trace_id、Idempotency-Key或If-Match（按API_CONTRACT）。

## Output

返回Interfaces右侧的具名结果/明确文件产物，包含本任务Test Cases所列可观察值；不能只返回任意dict或成功布尔。业务失败保留类型化原因；候选/已验证/已确认分别表达；任何正式新方案必须带version_id、parent_version_id、snapshot_hash和校验引用。本文档/测试任务只返回证据，不生成调度数据。

## Interfaces

本任务采用以下精确公开入口；多个入口用分号分隔，HTTP路径均带API_CONTRACT前缀：

```text
add_capacity_constraints(ctx: RoutingModelContext, problem: TransportProblem) -> None
```

新实现放在本任务Files并导出到既有组合根/注册入口时仅做必要装配；第三方引擎对象留在adapter内部。若签名需扩展，不得先改后解释：先写`contracts/changes/`说明输入输出影响。

## Data Contract

TransportProblem(snapshot,nodes:tuple[RoutingNode],vehicles:tuple[VehicleState],matrix:TravelMatrix,constraints,policy)；TransportSolution(status,engine_metadata,candidate:TransportPlan|None,validation:ValidationReport|None,diagnostics)。RoutingNode含业务ID、pickup/delivery类型、service_s、hard_window、load_delta；VehicleState含起终点、start_load、两维容量、setpoint、司机班次。

共享单位：整数秒/米/克/cm³/分/decic，UTC epoch；服务开始窗闭区间，占用[start,end)。Schema版本1.0.0，边界extra=forbid。Optional、未知、无解、超时的语义不得混淆；参考DATA_CONTRACTS的SolveStatus/JobStatus/错误表。

## Business Rules

重量与容积独立；载荷按各路段实际剩余量；纯配送起始载荷=车上分配货物总和，提货为正、送货为负。

所有业务结果绑定输入快照和规则版本。空输入仅在契约允许零需求时可返回有效空结果；有必需需求却无解不能返回空路线成功。已执行事实与已确认历史不可改写。

## Algorithm

两个 load dimensions；非零 start load 绑定路线分配；提送同车和先后；逐弧 0<=load<=capacity；不把累计已送量当实际载荷。

### Decision Variables

NextVar、VehicleVar、ActiveVar；Time/Weight/Volume CumulVar；仅本任务负责的构件可修改。

### Constraints

必需节点唯一服务、车辆起终点/资格、逐段载荷、提送同车先后、服务开始硬窗/班次、温控/货物资格；本任务新增项见Business Rules，其余沿用已有模块。

### Objective Function

距离弧成本与ObjectivePolicy整数分费用；未服务惩罚仅用于明确optional订单；禁止用罚分破坏硬约束；记录目标分项与溢出上界。

### Solver Configuration

OR-Tools精确锁版本；默认5000ms共享wall预算；初解PARALLEL_CHEAPEST_INSERTION，局部搜索GUIDED_LOCAL_SEARCH；参数仅使用当前锁版本支持字段；worker提供硬截止。

### Result Extraction

仅非空assignment提取业务ID/route/stop/arrival/service/depart/load/cost；保存engine_status与incumbent标记，不把启发式可行称全局最优。

### Validation

独立按原快照与矩阵重算；T1正例与本任务负例；时间预算耗尽区分未知/超时与已证明无解。

## Edge Cases

必须处理：T1 载重 800000g => 路段载荷 800000/400000/0；T1 容量降至 799999g 且单趟 => 不可行。

共同边界按本任务适用范围测试：空集合、重复ID、非法枚举/单位、负值/整数溢出、缺失关联、边界时间相等、过期revision、取消/超时、依赖不可用。对不适用项在Completion Report说明，不为制造覆盖率添加无意义断言。

## Error Handling

输入契约错误→INVALID_INPUT/422；非法状态→INVALID_TRANSITION；未知必需能力→UNSUPPORTED并拒绝有效结果；版本/资源/幂等冲突→409；权限→401/403；依赖不可用→503。求解TIMEOUT/UNKNOWN/INFEASIBLE为typed结果，不统一包装成500。

仅捕获明确可处理的第三方异常并保留cause/trace；边界可最后捕获未预期错误记录脱敏stack并返回INTERNAL_ERROR，禁止except Exception: pass。重试仅幂等暂态操作，有最大次数与deadline；不重试业务硬约束失败。

## Logging

事件名使用 `p07_02.started/completed/rejected`（纯函数由调用边界记录）。记录operation、trace_id、输入/输出hash、schema_version、结果状态、duration_ms、明确错误码；涉及求解追加引擎版本/配置/seed，涉及版本追加base/candidate/version引用。禁止输出secret、完整个人数据或模型内部思维。文档任务保存检查日志与文件hash。

## Observability

solver_runs_total{kind,status}、solver_build_seconds、solver_solve_seconds、validator_rejections_total{code}。

不得用order_id/vehicle_id/trace_id作metric标签；这些只在日志或trace。此阶段还没有完整监控backend时，先输出结构化测量/诊断，P37接统一出口；不能因此跳过可观察结果。

## Testing

- Unit Test：`tests/unit/test_p07_02_capacity_and_pickup.py`；测试本任务规则/转换/状态或文档检查负例。
- Integration Test：`tests/integration/test_p07_02_capacity_and_pickup.py`；验证真实相邻模块的数据/服务边界；涉及数据库使用隔离真实PostgreSQL。
- Solver Test：`tests/solver/test_p07_02_capacity_and_pickup.py`；真实OR-Tools与独立oracle/负例；约束覆盖不得只用mock。
- 所有测试均有确定数据和预期，不用固定假成功掩盖缺失实现；命令零用例或关键skip视为未验收。

## Test Cases

| 编号 | 明确输入 → 预期结果 | 断言要求 |
| --- | --- | --- |
| 1 | T1 载重 800000g => 路段载荷 800000/400000/0 | 必须按箭头右侧断言；禁止只断言status非空。 |
| 2 | T1 容量降至 799999g 且单趟 => 不可行 | 必须按箭头右侧断言；禁止只断言status非空。 |

正例数值来自TEST_FIXTURES手算；负例一次仅改指定字段，明确断言错误码/违规位置及无副作用。多可行解场景检查不变量/目标容许范围，不随意固定solver搜索顺序。

## Acceptance Criteria

1. Objective与Files交付完全对应，本任务所有具体Test Cases通过。
2. 下列命令实际执行且exit code=0，记录真实测试数量，不含关键skip/占位返回；编译成功不等于业务通过。
3. 无共享类型/生成客户端漂移，依赖边界检查通过；失败路径不产生半计划或伪成功。
4. 完成报告和任务文档齐备，并将证据交 `G07`：真实OR-Tools T1=9000m/1400分；容量/提送/硬窗/温区/状态各有反例；独立校验通过，无假成功。
5. 单任务成功不自动使Gate成功；当前Gate未通过，禁止开始下一Phase。

## Validation Commands

从仓库根目录执行。Phase01之后使用已锁定环境；数据库任务先按环境手册启动隔离PostgreSQL。以下为完成本任务后的强制命令，**本轮规划没有执行未来应用测试**：

```powershell
uv run pytest tests/unit/test_p07_02_capacity_and_pickup.py tests/integration/test_p07_02_capacity_and_pickup.py tests/solver/test_p07_02_capacity_and_pickup.py -q
uv run python scripts/check_architecture.py
```

如工具/依赖/凭据不可用，保留实际错误并记录未执行项，不能写全部通过。修改失败后只重跑受影响测试和必需Gate；不得在未通过时跳阶段。

## Documentation

更新 `docs/implementation/P07-02.md`：已实现能力、接口/单位、输入输出样例、状态与失败语义、实际限制、关联测试。完成报告写 `docs/implementation/reports/P07-02.md`。公共契约变化另追加contracts/changes说明及架构issue，重新导出Schema/OpenAPI/TS并重验受影响Gate，不通过聊天补交接。

## Completion Report

最终答复和报告必须逐项包含：

- Files created（精确路径）
- Files modified（精确路径及原因）
- Tests added（文件、用例和覆盖的业务边界）
- Commands executed（实际命令、工作目录、环境）
- Test results（exit code、passed/failed/skipped数量、原始日志与产物位置）
- Known limitations（支持/不支持及用户可见行为）
- Remaining risks（有证据的风险、影响、下一责任任务）

另记录Task ID、契约版本前后、输入/输出hash、当前代码revision/相关文件hash、Gate证据引用。不得声称尚未运行的测试通过，不把本任务完成说成整个系统完成。
