"""Stdlib checks for planning artifacts. Never runs or certifies application tests."""
from pathlib import Path
from datetime import datetime, timezone
from copy import deepcopy
import argparse
import hashlib
import json
import io
import platform
import re
import sys
import unittest

ROOT=Path(__file__).resolve().parents[2]
REQUIRED=['Context','Current State','Objective','Scope','Out of Scope','Architecture Constraints','Files','Domain Model','Input','Output','Interfaces','Data Contract','Business Rules','Algorithm','Edge Cases','Error Handling','Logging','Observability','Testing','Test Cases','Acceptance Criteria','Validation Commands','Documentation','Completion Report']
OR_FIELDS=['Decision Variables','Constraints','Objective Function','Solver Configuration','Result Extraction','Validation']
ENTITY_NAMES=['Order','Cargo','Vehicle','Driver','Warehouse','WarehouseZone','StorageLocation','Dock','Worker','Equipment','TransportTask','WarehouseTask','Route','RouteStop','Schedule','ScheduleTask','ScheduleVersion','Constraint','OptimizationRequest','OptimizationResult','Simulation','SimulationSnapshot','Event','ExceptionEvent','RescheduleRequest','RescheduleResult','AgentRun','ToolCall','DecisionRecord','Experiment','Metric','ExperimentResult']
EXPECTED_GROUPS={'00-master','01-foundation','02-domain','03-database','04-api','05-transport-solver','06-warehouse-solver','07-simulation','08-exception','09-agents','10-frontend','11-evaluation','12-integration','13-release'}
MASTER_HEADINGS=['项目目标','非目标','架构原则','系统上下文','技术架构','模块划分','模块依赖图','Domain Model','API Boundary','Agent Boundary','Solver Boundary','Simulation Boundary','数据库边界','前端边界','测试策略','Observability','Security','Demo Strategy','Milestones','Definition of Done']

def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def validate_graph(data):
    errors=[];nodes=data['tasks']+data['gates'];by_id={n['id']:n for n in nodes}
    if len(by_id)!=len(nodes):errors.append('duplicate node id')
    for n in nodes:
        for d in n['deps']:
            if d not in by_id:errors.append(f'{n["id"]}: missing dependency {d}')
        actual={q['id'] for q in nodes if n['id'] in q['deps']}
        if actual!=set(n.get('blocks',[])):errors.append(f'{n["id"]}: reverse blocks mismatch')
    color={};anc={}
    def visit(x):
        if color.get(x)==1:raise ValueError('cycle: '+x)
        if color.get(x)==2:return anc[x]
        color[x]=1;result=set()
        for d in by_id[x]['deps']:
            if d in by_id:result.add(d);result.update(visit(d))
        color[x]=2;anc[x]=result;return result
    try:
        for n in nodes:visit(n['id'])
    except ValueError as exc:errors.append(str(exc));return errors
    for t in data['tasks']:
        for pid in t.get('parallel',[]):
            q=by_id.get(pid)
            if not q:errors.append('missing parallel task '+pid);continue
            if q['phase']!=t['phase']:errors.append('parallel crosses phase gate')
            if pid in anc[t['id']] or t['id'] in anc[pid]:errors.append('parallel dependency conflict')
            if set(q.get('allowed_files',[]))&set(t.get('allowed_files',[])):errors.append('parallel write conflict')
            if t['id'] not in q.get('parallel',[]):errors.append('parallel relation is not symmetric')
    return errors

def validate_prompt(body,tid,solver=False):
    errors=[];headings=re.findall(r'^## (.+)$',body,re.M)
    if headings!=REQUIRED:errors.append(tid+': missing, duplicate or reordered required section')
    sections=re.split(r'^## .+$',body,flags=re.M)[1:]
    if any(len(s.strip())<25 for s in sections):errors.append(tid+': empty/trivial section')
    if solver:
        for name in OR_FIELDS:
            if not re.search(r'^### '+re.escape(name)+r'$',body,re.M):errors.append(tid+': missing OR section '+name)
    for token in ['Files created','Files modified','Tests added','Commands executed','Test results','Known limitations','Remaining risks','Unit Test','Integration Test','docs/architecture/issues/','fake implementation','hard-coded demo answer']:
        if token not in body:errors.append(tid+': missing required item '+token)
    if '```powershell\n' not in body:errors.append(tid+': missing executable command block')
    return errors

def local_links(path,root):
    errors=[];text=path.read_text(encoding='utf-8-sig')
    # Ignore fenced examples; links in visible prose/tables remain checked.
    text=re.sub(r'```.*?```','',text,flags=re.S)
    for raw in re.findall(r'\[[^\]\n]+\]\(([^)\n]+)\)',text):
        dest=raw.strip().split('#',1)[0]
        if not dest or re.match(r'^[a-z]+://',dest):continue
        dest=dest.strip('<>')
        target=(path.parent/dest).resolve()
        if not target.is_relative_to(root.resolve()):errors.append(str(path)+': link escapes plan root '+dest)
        elif not target.exists():errors.append(str(path.relative_to(root))+': missing local link '+dest)
    return errors

def validate_artifacts(data,task_id=None):
    errors=validate_graph(data);tasks=data['tasks'];gates=data['gates']
    if len(gates)!=40 or {g['id'] for g in gates}!={f'G{p:02d}' for p in range(40)}:errors.append('40 numbered gates required')
    if {t['phase'] for t in tasks}!=set(range(40)):errors.append('phase coverage gap')
    if {Path(t['prompt']).parent.name for t in tasks}!=EXPECTED_GROUPS:errors.append('14 prompt group coverage mismatch')
    if len({t['prompt'] for t in tasks})!=len(tasks):errors.append('duplicate prompt path')
    selected=[t for t in tasks if not task_id or t['id']==task_id]
    if task_id and not selected:errors.append('unknown task '+task_id)
    for t in tasks:
        p=t['phase']
        if p>0 and f'G{p-1:02d}' not in t['deps']:errors.append(t['id']+': missing preceding phase gate')
        if t['phase_gate']!=f'G{p:02d}':errors.append(t['id']+': mismatched phase gate')
        if t['status']!='planned':errors.append(t['id']+': planning artifact claims implementation progress')
        if not t['files'] or not t['commands'] or len(t['cases'])<2:errors.append(t['id']+': missing concrete artifacts/commands/cases')
        if any(x.startswith(('demo/','demos/')) for x in t['allowed_files']):errors.append(t['id']+': modifies protected legacy')
        for field in ['unit_test','integration_test']:
            if not t.get(field):errors.append(t['id']+': missing '+field)
        for cmd in t['commands']:
            for test_path in re.findall(r'(?:tests/[A-Za-z0-9_./-]+\.(?:py|ts)|apps/frontend/src/test/[A-Za-z0-9_./-]+\.tsx)',cmd):
                if test_path not in t['allowed_files']:errors.append(t['id']+': command test path outside Files: '+test_path)
    for g in gates:
        if set(g['deps'])!={t['id'] for t in tasks if t['phase']==g['phase']}:errors.append(g['id']+': missing task gate dependency')
        if g['status']!='not_run':errors.append(g['id']+': planning artifact claims a passed gate')
    for t in selected:
        file=ROOT/t['prompt']
        if not file.exists():errors.append('missing prompt '+t['prompt']);continue
        body=file.read_text(encoding='utf-8')
        errors+=validate_prompt(body,t['id'],t['kind']=='solver')
        for command in t['commands']:
            if command not in body:errors.append(t['id']+': prompt/manifest command drift')
        for required_path in t['allowed_files']:
            if required_path not in body:errors.append(t['id']+': Files/manifest drift '+required_path)
    actual=set(p.relative_to(ROOT).as_posix() for p in (ROOT/'docs/prompts').glob('*/*.md'))
    expected={t['prompt'] for t in tasks}
    if actual!=expected:errors.append('orphaned or missing prompt files: '+str(actual^expected))
    master=(ROOT/'PROJECT_MASTER_PLAN.md').read_text(encoding='utf-8')
    for n,h in enumerate(MASTER_HEADINGS,1):
        if f'## {n}. {h}' not in master:errors.append('missing Master Plan section '+h)
    catalog=(ROOT/'docs/architecture/DOMAIN_CATALOG.md').read_text(encoding='utf-8')
    for name in ENTITY_NAMES:
        if f'| {name} /' not in catalog:errors.append('missing required entity '+name)
    if len(ENTITY_NAMES)!=32:errors.append('entity catalog checker has incorrect count')
    trace=(ROOT/'docs/plan/REQUIREMENTS_TRACEABILITY.md').read_text(encoding='utf-8')
    by_id={n['id'] for n in tasks+gates}
    for ref in re.findall(r'\b(?:P\d{2}-\d{2}|G\d{2})\b',trace):
        if ref not in by_id:errors.append('traceability has unknown node '+ref)
    paths=[ROOT/'PROJECT_MASTER_PLAN.md',ROOT/'TASK_GRAPH.md',ROOT/'AI-CODING-PLAN.md']
    for directory in ['docs/architecture','docs/api','docs/algorithms','docs/plan','docs/prompts']:
        paths.extend((ROOT/directory).rglob('*.md'))
    for path in paths:
        if path.name!='USER_REQUIREMENTS.md':errors+=local_links(path,ROOT)
    return errors,dict(tasks=len(tasks),gates=len(gates),prompt_groups=len(EXPECTED_GROUPS),required_prompt_sections=len(REQUIRED),required_entities=len(ENTITY_NAMES),markdown_files=len(paths),selected_prompts=len(selected))

class CheckerTests(unittest.TestCase):
    def fixture(self):
        tasks=[dict(id='P00-01',phase=0,deps=[],blocks=['P00-02'],parallel=[],allowed_files=['a']),dict(id='P00-02',phase=0,deps=['P00-01'],blocks=['G00'],parallel=[],allowed_files=['b'])]
        return dict(tasks=tasks,gates=[dict(id='G00',phase=0,deps=['P00-02'],blocks=[])])
    def test_valid_graph(self):self.assertEqual(validate_graph(self.fixture()),[])
    def test_cycle(self):
        d=self.fixture();d['tasks'][0]['deps']=['G00'];self.assertTrue(any('cycle' in x for x in validate_graph(d)))
    def test_missing_dependency(self):
        d=self.fixture();d['tasks'][1]['deps']=['P99-01'];self.assertTrue(any('missing dependency' in x for x in validate_graph(d)))
    def test_reverse_blocks(self):
        d=self.fixture();d['tasks'][0]['blocks']=[];self.assertTrue(any('blocks mismatch' in x for x in validate_graph(d)))
    def test_duplicate_id(self):
        d=self.fixture();d['tasks'].append(deepcopy(d['tasks'][0]));self.assertTrue(any('duplicate node' in x for x in validate_graph(d)))
    def test_parallel_dependency(self):
        d=self.fixture();d['tasks'][0]['parallel']=['P00-02'];d['tasks'][1]['parallel']=['P00-01'];self.assertTrue(any('parallel dependency' in x for x in validate_graph(d)))
    def test_parallel_write_collision(self):
        d=self.fixture();d['tasks'][1]['deps']=[];d['tasks'][0]['blocks']=[]
        for t in d['tasks']:t['allowed_files']=['shared'];t['parallel']=['P00-02' if t['id']=='P00-01' else 'P00-01']
        self.assertTrue(any('parallel write' in x for x in validate_graph(d)))
    def test_cross_phase_parallel(self):
        d=self.fixture();d['tasks'][1]['phase']=1;d['tasks'][0]['parallel']=['P00-02'];self.assertTrue(any('crosses phase' in x for x in validate_graph(d)))
    def test_missing_prompt_sections(self):self.assertTrue(validate_prompt('# incomplete','P00-01'))
    def test_reordered_prompt_sections(self):
        body='\n'.join('## '+x+'\n'+'x'*40 for x in reversed(REQUIRED));self.assertTrue(any('reordered' in x for x in validate_prompt(body,'P00-01')))
    def test_missing_solver_sections(self):
        body='\n'.join('## '+x+'\n'+'x'*40 for x in REQUIRED);self.assertEqual(sum('missing OR section' in x for x in validate_prompt(body,'P07-01',True)),6)
    def test_entity_set(self):self.assertEqual(len(set(ENTITY_NAMES)),32)

def run_self_tests():
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(CheckerTests)
    output=io.StringIO()
    result=unittest.TextTestRunner(stream=output,verbosity=2).run(suite)
    global SELF_TEST_LOG
    SELF_TEST_LOG=output.getvalue()
    print(SELF_TEST_LOG,file=sys.stderr)
    return result.wasSuccessful(),result.testsRun

def record_g00(data,counts):
    required=[]
    for t in data['tasks']:
        if t['phase']==0:
            required.extend(t['files']);required.append(t['task_doc']);required.append(t['report'])
    missing=[p for p in required if not (ROOT/p).is_file()]
    if missing:raise ValueError('G00 NOT recorded: Phase00 deliverables/reports missing: '+', '.join(missing))
    freeze=json.loads((ROOT/'docs/architecture/CONTRACT_FREEZE.json').read_text(encoding='utf-8'))
    required_contracts={'PROJECT_MASTER_PLAN.md','TASK_GRAPH.md','docs/architecture/ARCHITECTURE_OVERVIEW.md',
        'docs/architecture/DOMAIN_CATALOG.md','docs/architecture/DATA_CONTRACTS.md','docs/architecture/IMPLEMENTATION_CONVENTIONS.md',
        'docs/api/API_CONTRACT.md','docs/algorithms/OPTIMIZATION_CONTRACT.md','docs/algorithms/SIMULATION_CONTRACT.md',
        'docs/algorithms/METRICS_CONTRACT.md','docs/plan/TEST_FIXTURES.md','docs/plan/PHASE_GATES.md'}
    entries=freeze.get('artifacts',[])
    if not required_contracts.issubset({x.get('path') for x in entries}):raise ValueError('G00 NOT recorded: incomplete contract hash coverage')
    if freeze.get('unresolved_blocking_issues')!=[] or not freeze.get('reviewer') or not freeze.get('reviewed_at'):
        raise ValueError('G00 NOT recorded: blocking issues or missing review record')
    inventory=json.loads((ROOT/'docs/architecture/BASELINE_INVENTORY.json').read_text(encoding='utf-8'))
    baseline=inventory.get('entries',[])
    must_have={'demo/README.md','demo/DEV_LOG.md','demo/OWNERSHIP.json','demo/contracts/README.md'}
    if not must_have.issubset({x.get('source_path') for x in baseline}) or not any(x.get('source_path','').startswith('demo/backend/app/contracts/') for x in baseline):
        raise ValueError('G00 NOT recorded: missing legacy baseline coverage')
    for row in entries+[dict(path=x.get('source_path'),sha256=x.get('sha256')) for x in baseline]:
        relative=row.get('path')
        if not isinstance(relative,str):raise ValueError('G00 NOT recorded: invalid artifact path')
        target=(ROOT/relative).resolve()
        if not target.is_relative_to(ROOT) or not target.is_file() or sha(target)!=row.get('sha256'):
            raise ValueError('G00 NOT recorded: artifact hash mismatch '+relative)
    for t in data['tasks']:
        if t['phase']==0:
            report=(ROOT/t['report']).read_text(encoding='utf-8')
            for key in ['Files created','Files modified','Tests added','Commands executed','Test results','Known limitations','Remaining risks']:
                if key not in report:raise ValueError('G00 NOT recorded: incomplete report '+t['id'])
    log=ROOT/'artifacts/gates/G00-checks.log';log.parent.mkdir(parents=True,exist_ok=True)
    log.write_text(SELF_TEST_LOG+'\nArtifact validation:\n'+json.dumps(counts,ensure_ascii=False,indent=2)+'\nerrors=[]\n',encoding='utf-8')
    hashes={p:sha(ROOT/p) for p in required+sorted(required_contracts)}
    evidence=dict(schema_version='1.0.0',gate_id='G00',status='passed',scope='Phase00 document contract verification only',
        finished_at=datetime.now(timezone.utc).isoformat(),checker_counts=counts,
        code_revision='content-sha256:'+hashlib.sha256(json.dumps(hashes,sort_keys=True).encode()).hexdigest(),
        input_artifact_hashes=hashes,dependency_evidence_hashes={},environment_fingerprint=dict(python=platform.python_version(),os=platform.system()),
        commands=[dict(argv=['python','tools/ai_coding_plan/validate_plan.py','--self-test','--record-g00'],cwd=str(ROOT),exit_code=0,log_path='artifacts/gates/G00-checks.log',log_hash=sha(log))],
        reviewer=freeze['reviewer'],
        limitations=['No application gate has been executed. G01 must establish the runtime gate runner.'])
    out=ROOT/'artifacts/gates/G00.json';out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(evidence,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('Recorded Phase00 document evidence:',out)

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--self-test',action='store_true');parser.add_argument('--task');parser.add_argument('--record-g00',action='store_true');parser.add_argument('--write-report',action='store_true')
    args=parser.parse_args();ok=True;test_count=0
    if args.self_test:ok,test_count=run_self_tests()
    data=json.loads((ROOT/'docs/plan/TASK_MANIFEST.json').read_text(encoding='utf-8'))
    report_path=ROOT/'docs/plan/VERIFICATION_REPORT.md'
    # Ensure links can be checked on first report creation, before success is asserted.
    if args.write_report and not report_path.exists():report_path.write_text('# 规划验证报告\n\n检查执行中，尚未通过。\n',encoding='utf-8')
    errors,counts=validate_artifacts(data,args.task)
    if not ok:errors.append('checker self-tests failed')
    if args.record_g00:
        if not args.self_test:errors.append('--record-g00 requires --self-test')
        if not errors:
            try:record_g00(data,counts)
            except (ValueError,TypeError,KeyError) as exc:errors.append(str(exc))
    summary=dict(status='PASS' if not errors else 'FAIL',checker_tests=test_count,**counts,errors=errors)
    if args.write_report:
        content='# 规划验证报告\n\n'+f'日期：2026-09-12。结果：**{summary["status"]}**。仅验证本轮AI-CODING-PLAN文档系统；不是任何应用业务Gate签收。\n\n'
        content+='执行命令：`python tools/ai_coding_plan/validate_plan.py --self-test --write-report`。\n\n'
        content+='| 检查项 | 结果 |\n| --- | --- |\n'
        for name,value in counts.items():content+=f'| {name} | {value} |\n'
        content+=f'| 检查器正反例测试 | {test_count} |\n| 错误 | {len(errors)} |\n\n'
        content+='检查覆盖：任务及Gate DAG无环、依赖存在、Blocks反向一致、严格前阶段Gate、同阶段并行依赖/写文件冲突、14目录和Prompt一对一、24个必需章节、OR-Tools六项算法结构、Files与命令一致、32实体覆盖、需求任务引用、20项Master内容、本地Markdown链接。\n\n'
        content+='所有Task保留planned，G00–G39保留not_run。本次未执行未来pytest/浏览器/数据库/OR-Tools/SimPy/真实LLM/性能测试；未改变旧demo业务代码或外部任务状态。静态通过不能证明算法正确、实际性能或业务可用性，后续必须逐Prompt实现并提交Gate原始证据。\n'
        if errors:content+='\n错误：\n\n'+'\n'.join('- '+e for e in errors)+'\n'
        report_path.write_text(content,encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False,indent=2))
    return 1 if errors else 0

if __name__=='__main__':sys.exit(main())
